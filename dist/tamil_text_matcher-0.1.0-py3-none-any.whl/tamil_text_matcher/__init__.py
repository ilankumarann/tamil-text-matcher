from .core import compare, find_best_match
from .encoder import TamilPhoneticEncoder

__version__ = "0.1.0"
